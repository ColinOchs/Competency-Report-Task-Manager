var nonImportantClass = "far fa-star";
var importantClass = "fas fa-star";
var isImportant = false;
var isFormVisible = true;



function toggleImportant(){
    console.log("icon clicked!");
   
    if(isImportant){
        //non important
        isImportant = false;
        $("#iImportant").removeClass(importantClass);
    $("#iImportant").addClass(nonImportantClass);
    }
    else{
        //important
    $("#iImportant").removeClass(nonImportantClass);
    $("#iImportant").addClass(importantClass);
    isImportant = true;
    }
}

function toggleForm(){
    if(isFormVisible){
        //hide
        isFormVisible = false;
        $("#form").hide();
    }
    else{
        //show
        isFormVisible = true;
        $("#form").show();
    }
}


function saveTask(){
    console.log("task saved!");

    let title = $("#txtTitle").val();
    let important = $("#iImportant").val();
    let dueDate = $("#selDate").val();
    let contact = $("#txtContact").val();
    let location = $("#txtLocation").val();
    let desc = $("#txtDescription").val();
    let color = $("#selColor").val();

//validate
if(title.length < 5){
    //show an error
    alert("Title should be at least 5 chars long");
    return;
}
if(!dueDate){
    //show an error
    alert("Date is required");
    return;
}
if(!contact.length){
    alert("Contact info required");
    return;
}
if(!location.length){
    alert("location is required");
    return;
}
if(!desc.length){
    alert("a description is required");
    return;
}
    let task = new Task(isImportant,title,dueDate,contact,location,desc,color);
    let dataStr = JSON.stringify(task);

    console.log(task);
    console.log(dataStr);
  //save the task
$.ajax({
    type: "POST",
    url: "https://fsdiapi.azurewebsites.net/api/tasks/",
    data: dataStr,
    contentType: "application/json",
    success: function(data) {
        console.log("Save result", data);
        let savedTask = JSON.parse(data);
        //display
        displayTask(savedTask);
    },
    error: function(error){
        console.log("save failed",error);
    }
});

}

//clear the form (create a functn)
clearForm();

function clearForm(){
    $("txtTitle").val("");
    $("selDate").val("");
    $("txtContact").val("");
    $("txtLocation").val("");
    $("txtDescription").val("");
    $("selColor").val("");
}

function displayTask(task){
    //create the syntax
    let syntax = `<div id="${task._id}" class="task">
    <div class="info">
        <h3>${task.title}</h3>
        <p>${task.description}</p>
    </div>

        <label class="date">${task.dueDate}</label>

    <div class="extra">
        <label class="location">${task.location}</label>
    </div>    
    <div class="extra2">
        <label class="contact">${task.contact}</label>
    </div>
        <button onclick="deleteTask('${task._id}')" class="btn btn-sm btn-danger">Remove</button>

    </div>`;

    //append the syntax to an element on the screen
    $("#task-list").append(syntax);
}

function deleteTask(id) {
    console.log("deleting task", id);
    //$("#" = id).remove();
}
function clearData(){
    $.ajax({
        type:"DELETE",
        url: "https://fsdiapi.azurewebsites.net/api/tasks/clear/ColinTech",
        success: () =>{
            console.log("data cleared!");
            $("#tasks-list").html(""); //clear the contents of the div
        },
         error: (details) => {
            console.log("delete failed", details);
        }
    });
}


function retrieveTasks(){
    //https://fsdiapi.azurewebsites.net/api/tasks
    $.ajax({
        type:"GET",
        url: "https://fsdiapi.azurewebsites.net/api/tasks",
        success: function(data){
            let list = JSON.parse(data); //from string to object/array  -- for loop and print every task
            
            for(let i=0; i < list.length; i++) {
                let task = list[i];
                if(task.name ==="ColinTech"){
                    displayTask(task);
                }
        
            }
        },
        error: (error) => {
            console.log("retrieve failed", error);
        }
    });
}



function init(){
console.log("task manager");
// events
$("#iImportant").click(toggleImportant);
$("#btnToggleForm").click(toggleForm);
$("#btnsaveTask").click(saveTask);
$("#btndeleteTasks").click(clearData);
//load data
retrieveTasks();
}

window.onload = init;