//object constructor
function Dog(name,age){
    this.name = name;
    this.age = age;
}
class Cat{
    // auto called when creating objects
    constructor(name,age,color){
        this.name = name;
        this.age = age;
        this.color = color;
    }
}

function objects(){

    //object literal
    let d1 = {
        name: "Fido",
        age: 3,
    };

    let d2 = {
        name: "Barf",
        age: 7,
    }
    console.log(d1,d2);
            
}

// object contructor
let d3 = new Dog("Bitey", 4);
let d4 = new Dog("Shithead",34)
console.log(d3,d4);

// classes
let c1 = new Cat("Fritz", 4, "white");
let c2 = new Cat("Garfield", 5, "brown");
console.log(c1,c2);

function testRequest(){
   // https://restclass.azurewebsites.net/api/test
    $.ajax({
        type:"GET",
        url: "https://restclass.azurewebsites.net/api/test",
        success: function(response){
            console.log("server says: ", response);
        },
        error: function(error) {
            console.log("req failed", error);
        }
    });
}

//execute the fn
objects();

//testRequest();